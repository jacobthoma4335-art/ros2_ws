from setuptools import find_packages, setup
import os
from glob import glob

package_name = 'my_robot'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
    ('share/ament_index/resource_index/packages',
     ['resource/' + package_name]),
    ('share/' + package_name, ['package.xml']),
    (os.path.join('share', package_name, 'meshes'),
     glob('meshes/*')),
    (os.path.join('share', package_name, 'launch'),
     glob('launch/*.py')),
    ('share/' + package_name, ['manipulator_new.urdf']),
],
    install_requires=['setuptools'],
    zip_safe=True,
    description='My robot package',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
        ],
    },
)
